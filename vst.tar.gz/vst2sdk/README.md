**Moved to:** https://github.com/Iunusov/VST_SDK_2.4
